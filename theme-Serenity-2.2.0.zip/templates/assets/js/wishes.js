/**
 * Theme: theme-Serenity
 * Author: Serenity
 * Build: 2026-10-01 20:34:46
 * Fingerprint: 9ac9d5b43683cf67
 * Copyright (c) 2026 Serenity. All rights reserved.
 */

/**
 * Theme: theme-Serenity
 * Author: Serenity
 * Build: 2026-08-31 17:36:31
 * Fingerprint: 897f796e1b7f0d91
 * Copyright (c) 2026 Serenity. All rights reserved.
 */

/**
 * Theme: theme-Serenity
 * Author: Serenity
 * Build: 2026-07-05 00:01:15
 * Fingerprint: 1a93cc3686d739b8
 * Copyright (c) 2026 Serenity. All rights reserved.
 */

(function () {
  'use strict';

  var API = '/apis/anonymous.wishboard.aobp.cn/v1alpha1';
  var config = window.__WISH_CONFIG__ || {};
  var allTypes = config.wishTypes || [];
  var maxLen = config.maxContentLength || 200;

  var CARD_COLORS = {
    green:  'rgb(217,242,217)',
    yellow: 'rgb(249,247,217)',
    purple: 'rgb(229,215,255)',
    pink:   'rgb(255,224,227)',
    blue:   'rgb(199,240,255)',
    orange: 'rgb(255,216,168)'
  };

  var currentFilter = 'all';
  var selectedColor = 'green';
  var currentType = allTypes.length > 0 ? allTypes[0].spec.slug : 'treehole';
  var zCounter = 200;
  var isMobile = /Android|iPhone|iPad|iPod|webOS/i.test(navigator.userAgent) || window.innerWidth < 768;

  function initWishesPage() {
    initCards();
    initTabs();
    initColorPicker();
    initSubmit();
    initTypeToggle();
    initCharCounter();
    initDaysCounter();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initWishesPage);
  } else {
    initWishesPage();
  }

  function initCards() {
    var board = document.getElementById('wishBoard');
    if (!board) return;
    var cards = board.querySelectorAll('.wish-card');
    if (cards.length === 0) return;

    var bw = board.offsetWidth;
    var bh = board.offsetHeight;
    var cw = isMobile ? 150 : 230;
    var cardH = isMobile ? 130 : 160;
    var margin = isMobile ? 10 : 16;

    cards.forEach(function (card, i) {
      var rotation = (Math.random() * 6 - 3).toFixed(2);
      var color = card.dataset.color || 'green';
      var bg = CARD_COLORS[color] || CARD_COLORS.green;
      card.style.background = bg;

      var maxLeft = Math.max(bw - cw - margin, margin);
      var maxTop = Math.max(bh - cardH - margin, margin);
      var left = margin + Math.random() * (maxLeft - margin);
      var top = margin + Math.random() * (maxTop - margin);

      card.style.left = left + 'px';
      card.style.top = top + 'px';
      card.style.zIndex = zCounter++;
      card.style.transform = 'rotate(' + rotation + 'deg)';
      card.style.animation = 'wishCardIn 0.4s ease ' + (i * 50) + 'ms forwards';

      if (!isMobile) initDrag(card, board);
      card.addEventListener('mousedown', function () { card.style.zIndex = ++zCounter; });
    });
  }

  function initDrag(card, board) {
    var header = card.querySelector('.wish-card-header');
    if (!header) return;
    var startX, startY, origX, origY, dragging = false;

    header.addEventListener('mousedown', function (e) {
      e.preventDefault();
      dragging = true;
      card.classList.add('dragging');
      card.style.zIndex = ++zCounter;
      startX = e.clientX;
      startY = e.clientY;
      origX = card.offsetLeft;
      origY = card.offsetTop;

      function onMove(ev) {
        if (!dragging) return;
        var newLeft = origX + ev.clientX - startX;
        var newTop = origY + ev.clientY - startY;

        var bw = board.offsetWidth;
        var cw = card.offsetWidth;
        if (newLeft < 0) newLeft = 0;
        if (newLeft + cw > bw) newLeft = bw - cw;

        var bh = board.offsetHeight;
        var ch = card.offsetHeight;
        if (newTop + ch > bh) newTop = bh - ch;

        card.style.left = newLeft + 'px';
        card.style.top  = newTop + 'px';
      }
      function onUp() {
        dragging = false;
        card.classList.remove('dragging');
        document.removeEventListener('mousemove', onMove);
        document.removeEventListener('mouseup', onUp);
      }
      document.addEventListener('mousemove', onMove);
      document.addEventListener('mouseup', onUp);
    });
  }

  function initTabs() {
    document.querySelectorAll('.wish-tab').forEach(function (t) {
      t.addEventListener('click', function () {
        document.querySelectorAll('.wish-tab').forEach(function (x) { x.classList.remove('active'); });
        t.classList.add('active');
        currentFilter = t.dataset.filter;
        filterCards();
      });
    });
  }

  function filterCards() {
    var board = document.getElementById('wishBoard');
    var cards = board.querySelectorAll('.wish-card');
    var empty = document.getElementById('wishEmpty');
    var visible = 0;
    cards.forEach(function (c) {
      var type = c.dataset.type;
      var show = currentFilter === 'all' || type === currentFilter;
      if (!show) {
        c.style.display = 'none';
      } else {
        c.style.display = '';
        c.style.animation = 'none';
        c.style.opacity = '0';
        void c.offsetWidth; 
        c.style.animation = 'wishCardIn 0.4s ease ' + (visible * 40) + 'ms forwards';
        visible++;
      }
    });
    if (empty) empty.style.display = visible === 0 ? 'block' : 'none';
  }

  function initColorPicker() {
    document.querySelectorAll('.wish-color-dot').forEach(function (d) {
      d.addEventListener('click', function () {
        document.querySelectorAll('.wish-color-dot').forEach(function (x) { x.classList.remove('active'); });
        d.classList.add('active');
        selectedColor = d.dataset.color;
      });
    });
  }

  function initTypeToggle() {
    var btn = document.getElementById('wishTypeToggle');
    if (!btn) return;
    btn.addEventListener('click', function () {
      if (!allTypes.length) return;
      var idx = allTypes.findIndex(function (t) { return t.spec.slug === currentType; });
      var next = (idx + 1) % allTypes.length;
      currentType = allTypes[next].spec.slug;
      btn.textContent = allTypes[next].spec.displayName;
    });
  }

  function initCharCounter() {
    var input = document.getElementById('wishContent');
    if (!input) return;
    input.addEventListener('input', updateCharCounter);
    updateCharCounter();
  }
  function updateCharCounter() {
    var input = document.getElementById('wishContent');
    var counter = document.getElementById('wishCharCounter');
    if (!input || !counter) return;
    var len = input.value.length;
    counter.textContent = len + '/' + maxLen;
    counter.classList.toggle('over', len > maxLen);
  }

  function initSubmit() {
    var btn = document.getElementById('wishSubmitBtn');
    if (!btn) return;
    btn.addEventListener('click', function () {
      var content = document.getElementById('wishContent').value.trim();
      var nickname = document.getElementById('wishNick').value.trim() || '匿名';
      if (!content) { toast('写点什么吧'); return; }
      if (content.length > maxLen) { toast('内容超过' + maxLen + '字限制'); return; }
      btn.disabled = true; btn.textContent = '发布中...';
      fetch(API + '/wishes/-/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          content: content, nickname: nickname, color: selectedColor,
          type: currentType, anonymous: !nickname || nickname === '匿名'
        })
      }).then(function (r) { return r.json().then(function (d) { return { ok: r.ok, data: d }; }); })
        .then(function (res) {
          if (res.ok) {
            toast(res.data.message || '发布成功');
            document.getElementById('wishContent').value = '';
            updateCharCounter();
            if (res.data.status === 'approved' && res.data.wish) {
              insertNewCard(res.data.wish);
            }
          } else { toast(res.data.error || '提交失败'); }
        })
        .catch(function () { toast('网络错误'); })
        .finally(function () { btn.disabled = false; btn.textContent = '发布'; });
    });

    document.getElementById('wishContent').addEventListener('keydown', function (e) {
      if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); btn.click(); }
    });
  }

  function insertNewCard(wish) {
    var board = document.getElementById('wishBoard');
    if (!board) return;
    var spec = wish.spec || {};
    var color = spec.color || 'green';
    var type = spec.type || 'treehole';
    var bg = CARD_COLORS[color] || CARD_COLORS.green;

    var typeLabel = type;
    for (var i = 0; i < allTypes.length; i++) {
      if (allTypes[i].spec.slug === type) {
        typeLabel = allTypes[i].spec.displayName;
        break;
      }
    }

    var now = new Date(spec.createdAt || Date.now());
    var dateStr = now.getFullYear() + '/' + (now.getMonth() + 1) + '/' + now.getDate();

    var card = document.createElement('div');
    card.className = 'wish-card';
    card.dataset.type = type;
    card.dataset.color = color;
    card.style.background = bg;

    var html = '<div class="wish-card-header">'
      + '<div class="wish-dots"><span class="wish-dot red"></span><span class="wish-dot yellow"></span><span class="wish-dot green"></span></div>'
      + '<span class="wish-card-label">' + esc(typeLabel) + '</span>'
      + '</div>';

    var statusHtml = '';
    if (spec.status === 'doing') {
      statusHtml = ' <em class="wish-status-text">进行中</em>';
    } else if (spec.status === 'done') {
      statusHtml = ' <em class="wish-status-text">已达成</em>';
    }

    html += '<div class="wish-card-body">' + esc(spec.content || '') + statusHtml + '</div>';

    if (spec.doneNote) {
      html += '<div class="wish-card-done-note">' + esc(spec.doneNote) + '</div>';
    }
    if (spec.doneImage && spec.status === 'done') {
      html += '<img class="wish-card-done-img" src="' + esc(spec.doneImage) + '" alt="" loading="lazy" />';
    }
    if (spec.aiReply) {
      html += '<div class="wish-card-ai">' + esc(spec.aiReply) + '</div>';
    }

    var nickDisplay = spec.anonymous ? '匿名' : (spec.nickname || '匿名');
    html += '<div class="wish-card-footer">'
      + '<span class="wish-card-nick">' + esc(nickDisplay) + '</span>'
      + '<span>' + dateStr + '</span>'
      + '</div>';

    card.innerHTML = html;

    var bw = board.offsetWidth;
    var bh = board.offsetHeight;
    var cw = isMobile ? 180 : 230;
    var cardH = 160;
    var margin = 16;
    var maxLeft = Math.max(bw - cw - margin, margin);
    var maxTop = Math.max(bh - cardH - margin, margin);
    var left = margin + Math.random() * (maxLeft - margin);
    var top = margin + Math.random() * (maxTop - margin);
    var rotation = (Math.random() * 6 - 3).toFixed(2);

    card.style.left = left + 'px';
    card.style.top = top + 'px';
    card.style.zIndex = ++zCounter;
    card.style.transform = 'rotate(' + rotation + 'deg)';
    card.style.animation = 'wishCardIn 0.4s ease forwards';

    if (currentFilter !== 'all' && currentFilter !== type) {
      card.style.display = 'none';
    }

    board.appendChild(card);

    if (!isMobile) initDrag(card, board);
    card.addEventListener('mousedown', function () { card.style.zIndex = ++zCounter; });

    var empty = document.getElementById('wishEmpty');
    if (empty) empty.style.display = 'none';
  }

  function initDaysCounter() {
    var badge = document.getElementById('daysBadge');
    if (!badge) return;
    var dateStr = badge.dataset.date;
    var nameA = badge.dataset.nameA || '';
    var nameB = badge.dataset.nameB || '';
    if (!dateStr) return;
    var start = new Date(dateStr);
    if (isNaN(start.getTime())) return;
    var days = Math.floor((Date.now() - start.getTime()) / 86400000);
    var text = '';
    if (nameA && nameB) {
      text = '<span class="name">' + esc(nameA) + '</span> & <span class="name">' + esc(nameB) + '</span> 在一起 <span class="num">' + days + '</span> 天';
    } else {
      text = '在一起 <span class="num">' + days + '</span> 天';
    }
    document.getElementById('daysContent').innerHTML = text;
    badge.style.visibility = 'visible';
    if (typeof AOS !== 'undefined') AOS.refresh();
  }

  function toast(msg) {
    var t = document.getElementById('wishToast');
    if (!t) return;
    t.textContent = msg; t.classList.add('show');
    setTimeout(function () { t.classList.remove('show'); }, 2500);
  }
  function esc(s) {
    if (!s) return '';
    var d = document.createElement('div');
    d.textContent = s;
    return d.innerHTML;
  }
})();
