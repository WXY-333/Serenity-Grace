/**
 * Theme: theme-Serenity
 * Author: Serenity
 * Build: 2026-10-01 20:34:46
 * Fingerprint: 9ac9d5b43683cf67
 * Copyright (c) 2026 Serenity. All rights reserved.
 */

/**
 * Theme: theme-Serenity
 * Author: Serenity
 * Build: 2026-08-31 17:36:31
 * Fingerprint: 897f796e1b7f0d91
 * Copyright (c) 2026 Serenity. All rights reserved.
 */

/**
 * Theme: theme-Serenity
 * Author: Serenity
 * Build: 2026-07-05 00:01:15
 * Fingerprint: 1a93cc3686d739b8
 * Copyright (c) 2026 Serenity. All rights reserved.
 */

(function(){
  var el = document.getElementById('nav-music');
  if (!el) return;
  var tips = document.getElementById('nav-music-hoverTips');
  var panel = document.getElementById('music-panel');
  var ap = null;
  var playing = false;
  var panelOpen = false;
  var pauseFromPanel = false;

  var MIN_PANEL_WIDTH = 260;
  function syncPanelWidth() {
    if (!panel || !el) return;
    var w = el.offsetWidth;
    if (w >= MIN_PANEL_WIDTH) {
      panel.style.width = w + 'px';
    } else {
      panel.style.width = MIN_PANEL_WIDTH + 'px';
    }
  }
  var resizeObs = new ResizeObserver(function() { syncPanelWidth(); });
  resizeObs.observe(el);

  function getAccentColor() {
    var configured = getComputedStyle(document.documentElement).getPropertyValue('--color-accent').trim();
    if (configured) return configured;
    var isLight = document.documentElement.getAttribute('data-theme') === 'light';
    return isLight
      ? (window.__ACCENT_LIGHT || '#7DCDE8')
      : (window.__ACCENT_DARK || '#E87D98');
  }

  function applyThemeColor(inst) {
    if (!inst) return;
    inst.theme(getAccentColor());
  }

  function musicToggle(changePlay) {
    if (changePlay === undefined) changePlay = true;
    if (!ap) return;
    if (playing) {
      el.classList.remove('playing');
      tips.textContent = '播放音乐';
      playing = false;
    } else {
      el.classList.add('playing');
      el.classList.add('stretch');
      tips.textContent = '暂停音乐';
      playing = true;
    }
    if (changePlay) ap.toggle();
  }

  function musicTelescopic() {
    if (el.classList.contains('stretch')) {
      el.classList.remove('stretch');
    } else {
      el.classList.add('stretch');
    }
  }

  function openPanel() {
    if (!panel || panelOpen) return;
    panel.style.display = '';
    void panel.offsetHeight;
    panel.classList.add('active');
    panelOpen = true;
    syncPanelState();
  }

  function closePanel() {
    if (!panel || !panelOpen) return;
    panel.classList.remove('active');
    panelOpen = false;
    panel.addEventListener('transitionend', function handler() {
      if (!panel.classList.contains('active')) panel.style.display = 'none';
      panel.removeEventListener('transitionend', handler);
    });
  }

  function togglePanel() {
    if (panelOpen) closePanel(); else openPanel();
  }

  function fmtTime(s) {
    if (!s || isNaN(s)) return '0:00';
    s = Math.floor(s);
    var m = Math.floor(s / 60);
    var sec = s % 60;
    return m + ':' + (sec < 10 ? '0' : '') + sec;
  }

  function syncPanelState() {
    if (!ap || !panelOpen) return;
    var audio = ap.audio;
    var cur = ap.list.audios[ap.list.index];

    var coverEl = document.getElementById('mpCover');
    if (coverEl && cur) coverEl.src = cur.cover || '';

    var titleEl = document.getElementById('mpTitle');
    var artistEl = document.getElementById('mpArtist');
    if (titleEl && cur) titleEl.textContent = cur.name || 'Unknown';
    if (artistEl && cur) artistEl.textContent = cur.artist || 'Unknown';

    document.getElementById('mpCurrent').textContent = fmtTime(audio.currentTime);
    document.getElementById('mpDuration').textContent = fmtTime(audio.duration);

    var pct = audio.duration ? (audio.currentTime / audio.duration * 100) : 0;
    document.getElementById('mpPlayed').style.width = pct + '%';
    document.getElementById('mpThumb').style.left = pct + '%';

    var iconPlay = document.querySelector('.mp-icon-play');
    var iconPause = document.querySelector('.mp-icon-pause');
    if (iconPlay && iconPause) {
      iconPlay.style.display = ap.audio.paused ? '' : 'none';
      iconPause.style.display = ap.audio.paused ? 'none' : '';
    }

    document.getElementById('mpVolumeLevel').style.width = (ap.audio.volume * 100) + '%';

    var volIcon = document.querySelector('.mp-icon-vol');
    var muteIcon = document.querySelector('.mp-icon-mute');
    if (volIcon && muteIcon) {
      volIcon.style.display = ap.audio.volume > 0 ? '' : 'none';
      muteIcon.style.display = ap.audio.volume > 0 ? 'none' : '';
    }
  }

  function renderPlaylist() {
    if (!ap) return;
    var ul = document.getElementById('mpPlaylist');
    if (!ul) return;
    ul.innerHTML = '';
    ap.list.audios.forEach(function(song, i) {
      var li = document.createElement('li');
      if (i === ap.list.index) li.classList.add('mp-list-active');
      var indexEl = document.createElement('span');
      indexEl.className = 'mp-list-idx';
      indexEl.textContent = String(i + 1);
      var nameEl = document.createElement('span');
      nameEl.className = 'mp-list-name';
      nameEl.textContent = song.name || 'Unknown';
      var artistEl = document.createElement('span');
      artistEl.className = 'mp-list-artist';
      artistEl.textContent = song.artist || '';
      li.append(indexEl, nameEl, artistEl);
      li.addEventListener('click', function() {
        ap.list.switch(i);
        ap.play();
        renderPlaylist();
      });
      ul.appendChild(li);
    });
  }

  function bindPanelEvents() {
    document.getElementById('mpPlay').addEventListener('click', function(e) {
      e.stopPropagation();
      if (!ap.audio.paused) pauseFromPanel = true;
      ap.toggle();
    });

    document.getElementById('mpPrev').addEventListener('click', function(e) {
      e.stopPropagation();
      ap.skipBack();
      setTimeout(function() { syncPanelState(); renderPlaylist(); }, 300);
    });

    document.getElementById('mpNext').addEventListener('click', function(e) {
      e.stopPropagation();
      ap.skipForward();
      setTimeout(function() { syncPanelState(); renderPlaylist(); }, 300);
    });

    var modeBtn = document.getElementById('mpMode');
    modeBtn.addEventListener('click', function(e) {
      e.stopPropagation();
      var cur = ap.options.order;
      var next = cur === 'random' ? 'list' : 'random';
      ap.options.order = next;
      var orderBtn = el.querySelector('.aplayer-icon-order');
      if (orderBtn) {
        orderBtn.classList.toggle('aplayer-icon-order', next === 'list');
        orderBtn.classList.toggle('aplayer-icon-random', next === 'random');
      }
      updateModeIcons();
    });

    var loopBtn = document.getElementById('mpLoop');
    loopBtn.addEventListener('click', function(e) {
      e.stopPropagation();
      var cur = ap.options.loop;
      var next = cur === 'all' ? 'one' : (cur === 'one' ? 'none' : 'all');
      ap.options.loop = next;
      var loopIcon = el.querySelector('.aplayer-icon-loop');
      if (loopIcon) {
        loopIcon.classList.remove('aplayer-icon-loop', 'aplayer-icon-loop-once', 'aplayer-icon-loop-none');
        if (next === 'all') loopIcon.classList.add('aplayer-icon-loop');
        else if (next === 'one') loopIcon.classList.add('aplayer-icon-loop-once');
        else loopIcon.classList.add('aplayer-icon-loop-none');
      }
      updateModeIcons();
    });

    document.getElementById('mpListToggle').addEventListener('click', function(e) {
      e.stopPropagation();
      e.preventDefault();
      var listArea = document.getElementById('mpListArea');
      var btn = document.getElementById('mpListToggle');
      if (listArea.style.display === 'none') {
        listArea.style.display = '';
        btn.classList.add('active');
        renderPlaylist();
      } else {
        listArea.style.display = 'none';
        btn.classList.remove('active');
      }
    });

    var progressBar = document.getElementById('mpProgress');
    progressBar.addEventListener('click', function(e) {
      e.stopPropagation();
      var rect = progressBar.getBoundingClientRect();
      var pct = (e.clientX - rect.left) / rect.width;
      pct = Math.max(0, Math.min(1, pct));
      if (ap.audio.duration) {
        ap.seek(pct * ap.audio.duration);
      }
    });

    var volBar = document.getElementById('mpVolumeBar');
    volBar.addEventListener('click', function(e) {
      e.stopPropagation();
      var rect = volBar.getBoundingClientRect();
      var pct = (e.clientX - rect.left) / rect.width;
      pct = Math.max(0, Math.min(1, pct));
      ap.volume(pct);
      syncPanelState();
    });

    var savedVol = 0.7;
    document.getElementById('mpVolBtn').addEventListener('click', function(e) {
      e.stopPropagation();
      if (ap.audio.volume > 0) {
        savedVol = ap.audio.volume;
        ap.volume(0);
      } else {
        ap.volume(savedVol);
      }
      syncPanelState();
    });
  }

  function updateModeIcons() {
    if (!ap) return;
    setTimeout(function() {
      var modeBtn = document.getElementById('mpMode');
      var loopBtn = document.getElementById('mpLoop');

      var order = ap.options && ap.options.order ? ap.options.order : 'list';
      var isRandom = order === 'random';
      modeBtn.classList.toggle('active', isRandom);
      modeBtn.title = isRandom ? '随机播放' : '列表顺序';
      var orderIcon = modeBtn.querySelector('.mp-icon-order');
      var randomIcon = modeBtn.querySelector('.mp-icon-random');
      if (orderIcon) orderIcon.style.display = isRandom ? 'none' : '';
      if (randomIcon) randomIcon.style.display = isRandom ? '' : 'none';

      var loop = ap.options && ap.options.loop ? ap.options.loop : 'all';
      var isLooping = loop !== 'none';
      loopBtn.classList.toggle('active', isLooping);
      var loopAllIcon = loopBtn.querySelector('.mp-icon-loop-all');
      var loopOneIcon = loopBtn.querySelector('.mp-icon-loop-one');
      var loopNoneIcon = loopBtn.querySelector('.mp-icon-loop-none');
      if (loop === 'one') {
        loopBtn.title = '单曲循环';
        if (loopAllIcon) loopAllIcon.style.display = 'none';
        if (loopOneIcon) loopOneIcon.style.display = '';
        if (loopNoneIcon) loopNoneIcon.style.display = 'none';
      } else if (loop === 'all') {
        loopBtn.title = '列表循环';
        if (loopAllIcon) loopAllIcon.style.display = '';
        if (loopOneIcon) loopOneIcon.style.display = 'none';
        if (loopNoneIcon) loopNoneIcon.style.display = 'none';
      } else {
        loopBtn.title = '关闭循环';
        if (loopAllIcon) loopAllIcon.style.display = 'none';
        if (loopOneIcon) loopOneIcon.style.display = 'none';
        if (loopNoneIcon) loopNoneIcon.style.display = '';
      }
    }, 100);
  }

  var syncTimer = null;
  function startSync() {
    if (syncTimer) return;
    syncTimer = setInterval(function() {
      if (panelOpen) {
        syncPanelState();
      }
    }, 500);
  }

  var observer = new MutationObserver(function() {
    if (ap) applyThemeColor(ap);
  });
  observer.observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });

  var checkInterval = setInterval(function() {
    var metingEl = el.querySelector('meting-js');
    if (metingEl && metingEl.aplayer) {
      clearInterval(checkInterval);
      ap = metingEl.aplayer;
      
      applyThemeColor(ap);

      var musicEl = el.querySelector('.aplayer-music');
      var btnEl = el.querySelector('.aplayer-button');
      if (musicEl) musicEl.addEventListener('click', function() { musicTelescopic(); });
      if (btnEl) btnEl.addEventListener('click', function() { musicToggle(false); });

      ap.on('play', function() {
        if (!playing) musicToggle(false);
        syncPanelState();
        renderPlaylist();
      });
      ap.on('pause', function() {
        if (pauseFromPanel) {
          pauseFromPanel = false;
          if (playing) {
            el.classList.remove('playing');
            tips.textContent = '播放音乐';
            playing = false;
          }
          syncPanelState();
        } else {
          if (playing) {
            el.classList.remove('playing');
            el.classList.remove('stretch');
            tips.textContent = '播放音乐';
            playing = false;
          }
          closePanel();
        }
      });
      ap.on('listswitch', function() {
        setTimeout(function() { syncPanelState(); renderPlaylist(); }, 200);
      });

      bindPanelEvents();
      startSync();

      var shouldAutoPlay = el.getAttribute('data-autoplay') === 'true';
      if (shouldAutoPlay) {
        var autoPlayDone = false;
        var doAutoPlay = function() {
          if (autoPlayDone) return;
          autoPlayDone = true;
          document.removeEventListener('click', doAutoPlay, true);
          document.removeEventListener('touchstart', doAutoPlay, true);
          document.removeEventListener('keydown', doAutoPlay, true);
          document.removeEventListener('scroll', doAutoPlay, true);
          if (ap && ap.audio.paused) {
            ap.play();
          }
        };

        document.addEventListener('click', doAutoPlay, true);
        document.addEventListener('touchstart', doAutoPlay, true);
        document.addEventListener('keydown', doAutoPlay, true);
        document.addEventListener('scroll', doAutoPlay, true);
      }
    }
  }, 500);

  tips.addEventListener('click', function() {
    if (!playing) {
      musicToggle();
      openPanel();
    } else {
      musicToggle();
    }
  });

  el.addEventListener('dblclick', function(e) {
    e.preventDefault();
    togglePanel();
  });

  el.addEventListener('click', function(e) {
    if (e.target === tips || e.target.closest('.nav-music-tips')) return;
    if (e.target.closest('.aplayer-button')) return;
    if (e.target.closest('.mp-btn')) return;
    if (playing) {
      togglePanel();
    }
  });
})();
